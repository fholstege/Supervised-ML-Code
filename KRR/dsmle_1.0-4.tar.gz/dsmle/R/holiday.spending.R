#' @name holiday.spending
#' @title Holiday Spending Data
#' @description Holiday spending data collected from 708 students on 8 variables in 2004 at 
#' Erasmus University Rotterdam.
NULL