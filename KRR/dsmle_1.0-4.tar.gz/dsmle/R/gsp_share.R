#' @name gsp_share
#' @title GSP Share Data
#' @description A short description.
#' 
NULL