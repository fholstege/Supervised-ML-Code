#' @name longley
#' @title Longley Data
#' @description A short description.
#' 
NULL