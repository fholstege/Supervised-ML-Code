#' @name admission
#' @title Admission Data
#' @description Admission to a graduate school of 400 applications. Four variables are available
#' \describe{
#'  \item{admission}{binary variable indicating admission }
#' }
#' 
NULL