#' @name Advertising
#' @title Advertising Data
#' @description Sales in thousands of units and advertsing budgets for three for 200 regions.
#' \describe{
#'  \item{TV}{Expenditure of advertising on TV in thousands of dollars per region.}
#'  \item{Radio}{Expenditure of advertising on radio in thousands of dollars per region.}
#'  \item{Newspaper}{Expenditure of advertising in newspapers in thousands of dollars per region.}
#'  \item{Sales}{Sales in thousands of units per region.}
#' }
#' 
NULL