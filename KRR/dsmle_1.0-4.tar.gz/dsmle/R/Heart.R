#' @name Heart
#' @title Heart Data
#' @description Health data on heart disease (yes, no) for 303 individuals.
#' 
NULL