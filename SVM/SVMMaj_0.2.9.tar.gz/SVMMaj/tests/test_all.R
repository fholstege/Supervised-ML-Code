library(testthat)
library(SVMMaj)
test_check("SVMMaj")
